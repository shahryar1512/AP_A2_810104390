#include <algorithm>
#include <iostream>
#include <iterator>
#include <vector>

using namespace std;

void reverseRange(vector<int>& wagons, int left, int right) {
    if (left >= right)
        return;

    swap(wagons[left], wagons[right]);
    reverseRange(wagons, left + 1, right - 1);
}

void reverseGroups(vector<int>& wagons, int groupSize, int start = 0) {
    int end = start + groupSize;
    // گروه ناقص دست نمی‌خوره
    if (end > static_cast<int>(wagons.size()))
        return;

    reverseRange(wagons, start, end - 1);
    reverseGroups(wagons, groupSize, end);
}

void printWagons(const vector<int>& wagons, size_t index = 0) {
    if (index == wagons.size())
        return;

    if (index > 0)
        cout << " ";
    cout << wagons[index];
    printWagons(wagons, index + 1);
}

int main() {
    int count, groupSize;
    cin >> count >> groupSize;

    vector<int> wagons(count);
    copy_n(istream_iterator<int>(cin), count, wagons.begin());

    reverseGroups(wagons, groupSize);
    printWagons(wagons);
    cout << endl;
}
