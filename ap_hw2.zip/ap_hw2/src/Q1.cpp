#include <iostream>
#include <string>

using namespace std;

void removeRepeats(const string& text, string& result, size_t index = 0) {
    if (index == text.size())
        return;

    // اگه با حرف قبلی فرق داشت نگهش می‌داریم
    if (index == 0 || text[index] != text[index - 1])
        result += text[index];
    removeRepeats(text, result, index + 1);
}

int main() {
    string text, result;
    cin >> text;
    removeRepeats(text, result);
    cout << result << endl;
}
