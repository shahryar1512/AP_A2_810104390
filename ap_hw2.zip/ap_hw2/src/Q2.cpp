#include <iostream>
#include <string>

using namespace std;

string expand(int number) {
    if (number <= 1)
        return to_string(number);

    // دو تیکه‌ی کناری یکی هستن، پس یه بار حسابشون می‌کنیم
    string side = expand(number / 2);
    return side + to_string(number % 2) + side;
}

int main() {
    int number;
    cin >> number;
    cout << expand(number) << endl;
}
