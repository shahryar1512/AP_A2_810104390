#include <algorithm>
#include <iostream>
#include <iterator>
#include <string>
#include <vector>

using namespace std;

struct Cell {
    int row, col;
};

struct Square {
    int top, left, size;
    Cell filled;  // خونه‌ای که از قبل پر شده
};

const char EMPTY = ' ';
const char HOLE = '.';

vector<string> yard;

char colorAt(int row, int col) {
    int size = yard.size();
    if (row < 0 || col < 0 || row >= size || col >= size)
        return EMPTY;
    return yard[row][col];
}

bool touchesColor(Cell cell, char color) {
    return colorAt(cell.row + 1, cell.col) == color || colorAt(cell.row - 1, cell.col) == color ||
           colorAt(cell.row, cell.col + 1) == color || colorAt(cell.row, cell.col - 1) == color;
}

char pickColor(const vector<Cell>& tile) {
    auto isFree = [&](char color) {
        return ranges::none_of(tile, [&](Cell cell) { return touchesColor(cell, color); });
    };
    if (isFree('A'))
        return 'A';
    return isFree('B') ? 'B' : 'C';
}

void paint(const vector<Cell>& tile) {
    char color = pickColor(tile);
    ranges::for_each(tile, [&](Cell cell) { yard[cell.row][cell.col] = color; });
}

void tileSquare(Square square) {
    if (square.size == 1)
        return;

    int half = square.size / 2;
    int midRow = square.top + half;
    int midCol = square.left + half;

    vector<Cell> centers = {
        {midRow - 1, midCol - 1}, {midRow - 1, midCol}, {midRow, midCol - 1}, {midRow, midCol}};
    Square quadrants[] = {{square.top, square.left, half, centers[0]},
                          {square.top, midCol, half, centers[1]},
                          {midRow, square.left, half, centers[2]},
                          {midRow, midCol, half, centers[3]}};

    int holeQuadrant = (square.filled.row >= midRow ? 2 : 0) + (square.filled.col >= midCol ? 1 : 0);
    quadrants[holeQuadrant].filled = square.filled;
    centers.erase(centers.begin() + holeQuadrant);
    paint(centers);

    // ترتیب مهمه، با این ترتیب همیشه یه رنگ آزاد پیدا می‌شه
    tileSquare(quadrants[0]);
    tileSquare(quadrants[3]);
    tileSquare(quadrants[1]);
    tileSquare(quadrants[2]);
}

int main() {
    int size, row, col;
    cin >> size >> row >> col;
    row--;
    col--;

    yard.assign(size, string(size, EMPTY));
    yard[row][col] = HOLE;
    tileSquare({0, 0, size, {row, col}});
    copy(yard.begin(), yard.end(), ostream_iterator<string>(cout, "\n"));
}
